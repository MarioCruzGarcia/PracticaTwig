<?php

require_once 'db/Database.php';
require_once 'model/Model.php';

class PedidoHasEstado implements Model
{
    private $id_pedido;
    private $id_estado;
    private $fecha;

    public function __construct()
    {
    }

    public function getIdPedido(): int|null
    {
        return $this->id_pedido;

    }

    public function setIdPedido($id_pedido): void
    {
        $this->id_pedido = $id_pedido;
    }

    public function getIdEstado(): int|null
    {
        return $this->id_estado;
    }

    public function setIdEstado($id_estado): void
    {
        $this->id_estado = $id_estado;
    }

    public function getFecha(): string|null
    {
        return $this->fecha;
    }

    public function setFecha($fecha): void
    {
        $this->fecha = $fecha;
    }

    public function findAll(): array
    {
        // 1. Conectarse a la base de datos
        $database = new Database('root', '', 'localhost', 3306);
    
        // 2. Realizar la query
        $result = $database->query('
            SELECT 
                pedidos.id AS id_pedido, 
                clientes.nombre AS nombre_cliente, 
                estado.nombre AS nombre_estado,
                pedido_has_estado.fecha AS fecha_estado
            FROM pedidos
            INNER JOIN clientes ON pedidos.id_cliente = clientes.id
            INNER JOIN pedido_has_estado ON pedidos.id = pedido_has_estado.id_pedido
            INNER JOIN estado ON pedido_has_estado.id_estado = estado.id;
        ');
        
        // 3. Recoger los resultados y desconectar de la base de datos
        $pedidos_estados = $result->fetchAll(PDO::FETCH_ASSOC);
        $database->desconectar();
    
        return $pedidos_estados;
    }
    

    public function findById($id)
    {
        // 1. Recibir el id que necesitamos buscar.
        // 2. Realizar la query
        // 3. Retornar el objeto PedidoHasEstado
        $query = "SELECT * FROM pedido_has_estado WHERE id_pedido = $id";
        $database = new Database('root', '', 'localhost', 3306);
        $pedido_estado = $database->query($query);
        $database = Database::desconectar();
        return $pedido_estado;
    }

    public function store($datos)
    {
        // 1. Recorrer la estructura $datos.
        // 2. Generar sentencia insert con esos datos.
        // 2.1. Imprimir por pantalla antes de insertar.
        // 2.2. Ejecutar esa sentencia SQL.

        $query = "INSERT INTO pedido_has_estado (id_pedido, id_estado, fecha) VALUES (:id_pedido, :id_estado, :fecha)";

        // Conectar a la base de datos, ejecutar y desconectar.
        $database = new Database('root', '', 'localhost', 3306);
    
        $database->exec($query);
        $database = Database::desconectar();
    }

    public function updateById($id)
    {
        // 1. Conectar a la base de datos.
        // 2. Construir la query para actualizar datos
        // 3. Ejecutar la query
        // 4. Desconectar de la base de datos

        $query = "UPDATE pedido_has_estado SET ";

        $datos = array();

        // Comprobamos valores getXX de id_pedido, id_estado, fecha
        // Si hay contenido, concateno.
        // Si no hay contenido, no hago nada

        if ($this->getIdPedido() != null) {
            $query = $query . "id_pedido = :id_pedido, ";
        }

        if ($this->getIdEstado() != null) {
            $query = $query . "id_estado = :id_estado, ";
        }

        if ($this->getFecha() != null) {
            $query = $query . "fecha = :fecha, ";
        }

        // Eliminamos la última coma y añadimos WHERE
       # Recorrer los elementos de $datos
       $keys = array_keys($datos);
       // var_dump($datos);
       // var_dump($keys);

       foreach ($datos as $key => $value) {
           # estoy en el ultimo caso. NO PONGO COMA AL FINAL
           if ($key === end($keys)) {
               $query = $query . " $key = '$value'";
               
           } else {
               # Estoy en un caso normal. PONGO COMA AL FINAL
               $query = $query . " $key = '$value', ";
               
           }
       }
       // var_dump('CASO FINAL: '. $query);
       // exit();
       $query = $query . " WHERE id =" . $id['id'];
        
       $db = new Database('root', '', 'localhost', 3306);
       $db->conectar();

       $resultado = $db->query($query);


       if ($resultado == 1) {
           $_SESSION['mensaje'] = 'Actualizado correctamente';
       } else {
           $_SESSION['mensaje'] = 'Error al actualizar. MIRAR MODELO';
       }
       $db = Database::desconectar();
    }

    public function destroyById($id): void
    {
        // 1. Conectar a la base de datos
        // 2. Realizar la query correspondiente.
        // 3. Desconectar de la base de datos.

        $database = new Database('root', '', 'localhost', 3306);
        $query = "DELETE FROM pedido_has_estado WHERE id = $id";
        $database->exec($query);
        $database = Database::desconectar();
    }
}

?>