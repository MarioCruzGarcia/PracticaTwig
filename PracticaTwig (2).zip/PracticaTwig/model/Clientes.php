<?php

require_once 'db/Database.php';
require_once 'model/Model.php';

class Clientes implements Model
{
    /**
     * NO FUNCIONAN NINGUNO DE LOS METODOS DE BASE DE DATOS SALVO FINDALL
     */
    private $id;
    private $dni;
    private $nombre;
    private $apellido;
    private $correo;
    private $direccion;

    public function __construct()
    {
    }

    public function getId(): int|null
    {
        return $this->id;
    }
    public function setId($id): void
    {
        $this->id = $id;
    }

    public function getdni(): string|null
    {
        return $this->dni;
    }

    public function setdni($dni): void
    {
        $this->dni = $dni;
    }

    public function getnombre(): string|null
    {
        return $this->nombre;
    }

    public function setnombre($nombre): void
    {
        $this->nombre = $nombre;
    }

    public function getapellido(): string|null
    {
        return $this->apellido;
    }

    public function setapellido($apellido): void
    {
        $this->apellido = $apellido;
    }

    public function getcorreo(): string|null
    {
        return $this->correo;
    }

    public function setcorreo($correo): void
    {
        $this->correo = $correo;
    }

    public function getdireccion(): string|null
    {
        return $this->direccion;
    }

    public function setdireccion($direccion): void
    {
        $this->direccion = $direccion;
    }


    public function findAll(): array
    {
        // 1. Conectarse a la base de datos
        $database = new Database('root', '', 'localhost', 3306);

        // 2. Realizar la query
        $result = $database->query('SELECT * FROM clientes');

        // 3. Desconectarse de la base de datos
        $database->desconectar();

        // 4. Convertir los resultados en objetos Clientes y devolverlos como una matriz
        $clientes = [];
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $cliente = new Clientes();
            $cliente->setId($row['id']);
            $cliente->setdni($row['dni']);
            $cliente->setnombre($row['nombre']);
            $cliente->setapellido($row['apellido']);
            $cliente->setcorreo($row['correo']);
            $cliente->setdireccion($row['direccion']);
            $clientes[] = $cliente;
        }

        return $clientes;
    }

    public function findById($id)
    {
        /**
         * 1. Recibir el id que necesitamos buscar.
         * 2. Realizar la query
         * 3. Retornoar el usuario
         */
        $query = "SELECT * FROM clientes WHERE id = $id";
        $database = new Database('root', '', 'localhost', 3306);
        $user = $database->query($query);
        $database = Database::desconectar();
        return $user;
    }

    /**
     * CAMBIARLO PARA ADAPTAR A LA NUEVA FUNCIONALIDAD
     */
    public function store($datos)
    {
        /**
         * 1. Recorrer la estructura $datos.
         * 2. Generar sentencia insert con esos datos.
         * 2.1. Imprimir por pantalla antes de insertar.
         * 2.2. Ejecutar esa sentencia SQL.
         */
        # Formato de query: INSERT INTO tabla (campo1, etc) VALUES (val1, etc);
        // $query = "INSERT INTO users (".implode(",",array_keys($datos)).", apellido_id) VALUES ('".implode("','",array_values($datos))."', 2)";

        # Conectar a la base de datos, ejecutar y desconectar.
        // $db = Database::conectar();
        // $db->exec($query);
        // $db = Database::desconectar();
    }

    public function updateById($id)
    {
        /**
         * 1. Conectar a la base de datos.
         * 2. Construir la query para actualizar datos
         * 3. Ejecutar la query
         * 4. Desconectar de la base de datos
         */
        $query = "UPDATE clientes SET";
        /**
         * Comprobamos valores getXX de id, dni, nombre, apellido_id
         * Si hay contenido, concateno.
         * Si no hay contenido, no hago nada
         */

        # $datos contiene un array con todos los datos existentes para actualizar
        $datos = array();

        if ($this->getdni() != null) {
            $datos['dni'] = $this->getdni();
        }
        if ($this->getnombre() != null) {
            $datos['nombre'] = $this->getnombre();
        }

        # Recorrer los elementos de $datos
        $keys = array_keys($datos);
        // var_dump($datos);
        // var_dump($keys);

        foreach ($datos as $key => $value) {
            # estoy en el ultimo caso. NO PONGO COMA AL FINAL
            if ($key === end($keys)) {
                $query = $query . " $key = '$value'";
                var_dump('ULTIMO CASO: ' . $query);
            } else {
                # Estoy en un caso normal. PONGO COMA AL FINAL
                $query = $query . " $key = '$value', ";
                var_dump('CASO NORMAL: ' . $query);
            }
        }
        // var_dump('CASO FINAL: '. $query);
        // exit();
        $query = $query . " WHERE id =" . $id['id'] ;
        // var_dump('QUERY FINAL: '. $query);
        // exit();
        $database = new Database('root', '', 'localhost', 3306);
        
        $resultado = $database->exec($query);

        if ($resultado == 1) {
            $_SESSION['mensaje'] = 'Actualizado correctamente';
        } else {
            $_SESSION['mensaje'] = 'Error al actualizar. MIRAR MODELO';
        }
        $database = Database::desconectar();
    }

    public function destroyById($id): void
    {
        /**
         * 1. Conectar a la base de datos
         * 2. Realizar la query correspondiente.
         * 3. Desconectar de la base de datos.
         */
        $database = new Database('root', '', 'localhost', 3306);
        $query = "DELETE FROM users WHERE id = $id";
        $database->exec($query);
        $database = Database::desconectar();
    }
}

?>