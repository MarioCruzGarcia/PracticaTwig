<?php

require_once 'db/Database.php';
require_once 'model/Model.php';

class Pedidos_has_Productos implements Model
{
    private $id_pedido;
    private $id_producto;
    private $cantidad;
    private $precio_unitario;

    public function __construct()
    {
    }

    public function getIdPedido(): int|null
    {
        return $this->id_pedido;

    }

    public function setIdPedido($id_pedido): void
    {
        $this->id_pedido = $id_pedido;
    }

    public function getIdProducto(): int|null
    {
        return $this->id_producto;
    }

    public function setIdProducto($id_producto): void
    {
        $this->id_producto = $id_producto;
    }

    public function getCantidad(): int|null
    {
        return $this->cantidad;
    }

    public function setCantidad($cantidad): void
    {
        $this->cantidad = $cantidad;
    }

    public function getPrecioUnitario(): float|null
    {
        return $this->precio_unitario;
    }

    public function setPrecioUnitario($precio_unitario): void
    {
        $this->precio_unitario = $precio_unitario;
    }

    public function findAll(): array
    {
        $database = new Database('root', '', 'localhost', 3306);
        $result = $database->query('SELECT * FROM pedidos_has_productos');
        $database->desconectar();

        $pedidos_has_productos = [];
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $pedido_has_producto = new Pedidos_has_productos();
            $pedido_has_producto->setIdPedido($row['id_pedido']);
            $pedido_has_producto->setIdProducto($row['id_producto']);
            $pedido_has_producto->setCantidad($row['cantidad']);
            $pedido_has_producto->setPrecioUnitario($row['precio_unitario']);
            $pedidos_has_productos[] = $pedido_has_producto;
        }

        return $pedidos_has_productos;
    }

    public function findById($id)
    {
        $query = "SELECT * FROM pedidos_has_productos WHERE id_pedido = $id";
        $database = new Database('root', '', 'localhost', 3306);
        $pedido_has_producto = $database->query($query);
        $database->desconectar();

        if ($pedido_has_producto && count($pedido_has_producto) > 0) {
            $this->setIdPedido($pedido_has_producto[0]['id_pedido']);
            $this->setIdProducto($pedido_has_producto[0]['id_producto']);
            $this->setCantidad($pedido_has_producto[0]['cantidad']);
            $this->setPrecioUnitario($pedido_has_producto[0]['precio_unitario']);
        }

        return $pedido_has_producto;
    }

    public function store($datos)
    {
        $query = "INSERT INTO pedidos_has_productos (id_pedido, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        $database = new Database('root', '', 'localhost', 3306);
        $stmt = $database->prepare($query);
        $stmt->execute([$datos['id_pedido'], $datos['id_producto'], $datos['cantidad'], $datos['precio_unitario']]);
        $database->desconectar();
    }

    public function updateById($id)
    {
        $query = "UPDATE pedidos_has_productos SET id_pedido = ?, id_producto = ?, cantidad = ?, precio_unitario = ? WHERE id_pedido = ?";
        $database = new Database('root', '', 'localhost', 3306);
        $stmt = $database->prepare($query);
        $stmt->execute([$datos['id_pedido'], $datos['id_producto'], $datos['cantidad'], $datos['precio_unitario'], $id]);
        $database->desconectar();
    }


    public function destroyById($id): void
    {
        $query = "DELETE FROM pedidos_has_productos WHERE id_pedido = ?";
        $database = new Database('root', '', 'localhost', 3306);
        $stmt = $database->prepare($query);
        $stmt->execute([$id]);
        $database->desconectar();
    }
}