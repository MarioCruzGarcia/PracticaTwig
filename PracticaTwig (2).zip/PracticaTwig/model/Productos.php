<?php

require_once 'db/Database.php';
require_once 'model/Model.php';

class Productos implements Model
{


    private $id;
    private $nombre;
    private $descripcion;
    private $precio;
    private $stock;

    public function __construct()
    {
    }

    public function getId(): int|null
    {
        return $this->id;
    }

    public function setId($id): void
    {
        $this->id = $id;
    }

    public function getNombre(): string|null
    {
        return $this->nombre;
    }

    public function setNombre($nombre): void
    {
        $this->nombre = $nombre;
    }

    public function getDescripcion(): string|null
    {
        return $this->descripcion;
    }

    public function setDescripcion($descripcion): void
    {
        $this->descripcion = $descripcion;
    }

    public function getPrecio(): float|null
    {
        return $this->precio;
    }

    public function setPrecio($precio): void
    {
        $this->precio = $precio;
    }

    public function getStock(): int|null
    {
        return $this->stock;
    }

    public function setStock($stock): void
    {
        $this->stock = $stock;
    }

    public function findAll(): PDOStatement
    {
        /**
         * 1. Me conecto a la base de datos.
         * 2. Realizo la query
         * 3. Me desconecto de la base de datos.
         * 4. Devuelvo la query
         */
        $db = new Database('root', '', 'localhost', 3306);
        $db->conectar();
        $query = "SELECT * FROM productos";
        $result = $db->query($query);
        $db = Database::desconectar();
        return $result;
    }

    public function findById($id)
    {
        $query = "SELECT * FROM productos WHERE id = $id";
        $database = new Database('root', '', 'localhost', 3306);
        $producto = $database->query($query);
        $database = Database::desconectar();
        return $producto;
    }

    public function store($datos)
    {
        // 1. Recorrer la estructura $datos.
        // 2. Generar sentencia insert con esos datos.
        // 2.1. Imprimir por pantalla antes de insertar.
        // 2.2. Ejecutar esa sentencia SQL.
        $query = "INSERT INTO productos (nombre, descripcion, precio, stock) VALUES ('" . $datos['nombre'] . "', '" . $datos['descripcion'] . "', " . $datos['precio'] . ", " . $datos['stock'] . ")";

        // Conectar a la base de datos, ejecutar y desconectar.
        $database = new Database('root', '', 'localhost', 3306);
        $database->exec($query);
        $database = Database::desconectar();
    }

    public function updateById($id)
    {

        $query = "UPDATE productos SET";

        $datos = array();

        if ($this->getnombre() != null) {
            $datos['nombre'] = $this->getnombre();
        }
        if ($this->getDescripcion() != null) {
            $datos['descripcion'] = $this->getDescripcion();
        }
        if ($this->getprecio() != null) {
            $datos['precio'] = $this->getprecio();
        }
        if ($this->getstock() != null) {
            $datos['stock'] = $this->getstock();
        }

        # Recorrer los elementos de $datos
        $keys = array_keys($datos);
        // var_dump($datos);
        // var_dump($keys);

        foreach ($datos as $key => $value) {
            # estoy en el ultimo caso. NO PONGO COMA AL FINAL
            if ($key === end($keys)) {
                $query = $query . " $key = '$value'";
                
            } else {
                # Estoy en un caso normal. PONGO COMA AL FINAL
                $query = $query . " $key = '$value', ";
                
            }
        }
        // var_dump('CASO FINAL: '. $query);
        // exit();
        $query = $query . " WHERE id =" . $id['id'];
         
        $db = new Database('root', '', 'localhost', 3306);
        $db->conectar();

        $resultado = $db->query($query);


        if ($resultado == 1) {
            $_SESSION['mensaje'] = 'Actualizado correctamente';
        } else {
            $_SESSION['mensaje'] = 'Error al actualizar. MIRAR MODELO';
        }
        $db = Database::desconectar();


        // $nombre = $_POST['nombre'];
        // $descripcion = $_POST['descripcion'];
        // $precio = $_POST['precio'];
        // $stock = $_POST['stock'];


        // $database = new Database('root', '', 'localhost', 3306);
        // $query = "
        //         UPDATE productos
        //         SET nombre = '$nombre',
        //             descripcion = '$descripcion',
        //             precio = '$precio',
        //             stock = $stock
                    
        //         WHERE id = $id;
        //     ";
        // var_dump($query);
        // $database->exec($query);
        // $database = Database::desconectar();

    }



    public function destroyById($id): void
    {
        // 1. Conectar a la base de datos
        // 2. Realizar la query correspondiente.
        // 3. Desconectar de la base de datos.
        $database = new Database('root', '', 'localhost', 3306);
        $query = "DELETE FROM productos WHERE id = $id";
        $database->exec($query);
        $database = Database::desconectar();
    }
}
?>