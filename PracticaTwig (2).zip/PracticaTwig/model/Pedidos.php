<?php

require_once 'db/Database.php';
require_once 'model/Model.php';

class Pedidos implements Model{

   private $id;
   private $fecha;
   private $id_cliente;
   private $direccion_entrega;
   private $total;

   public function __construct(){
   }

   public function getId() : int | null{
       return $this->id;
   }

   public function setId($id) : void{
       $this->id = $id;
   }

   public function getFecha() : string | null{
       return $this->fecha;
   }

   public function setFecha($fecha) : void{
       $this->fecha = $fecha;
   }

   public function getIdCliente() : int | null{
       return $this->id_cliente;
   }

   public function setIdCliente($id_cliente) : void{
       $this->id_cliente = $id_cliente;
   }

   public function getDireccionEntrega() : string | null{
       return $this->direccion_entrega;
   }

   public function setDireccionEntrega($direccion_entrega) : void{
       $this->direccion_entrega = $direccion_entrega;
   }

   public function getTotal() : float | null{
       return $this->total;
   }

   public function setTotal($total) : void{
       $this->total = $total;
   }

   public function findAll() : array{
       // 1. Conectarse a la base de datos
       $database = new Database('root', '', 'localhost', 3306);

       // 2. Realizar la query
       $result = $database->query('SELECT * FROM pedidos');

       // 3. Desconectarse de la base de datos
       $database->desconectar();

       // 4. Convertir los resultados en objetos Pedidos y devolverlos como una matriz
       $pedidos = [] ;
       while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
           $pedido = new Pedidos();
           $pedido->setId($row['id']);
           $pedido->setFecha($row['fecha']);
           $pedido->setIdCliente($row['id_cliente']);
           $pedido->setDireccionEntrega($row['direccion_entrega']);
           $pedido->setTotal($row['total']);
           $pedidos[] = $pedido;
       }

       return $pedidos;
   }

   public function findById($id) 
    {
        /**
         * 1. Recibir el id que necesitamos buscar.
         * 2. Realizar la query
         * 3. Retornoar el usuario
         */
        $query = "SELECT * FROM pedidos WHERE id = $id";
        $database = new Database('root', '', 'localhost', 3306);
        $user = $database->query($query);
        $database = Database::desconectar();
        return $user;
    }

    /**
     * CAMBIARLO PARA ADAPTAR A LA NUEVA FUNCIONALIDAD
     */
    public function store($datos)
    {
        /**
         * 1. Recorrer la estructura $datos.
         * 2. Generar sentencia insert con esos datos.
         * 2.1. Imprimir por pantalla antes de insertar.
         * 2.2. Ejecutar esa sentencia SQL.
         */
        # Formato de query: INSERT INTO tabla (campo1, etc) VALUES (val1, etc);
        // $query = "INSERT INTO users (".implode(",",array_keys($datos)).", apellido_id) VALUES ('".implode("','",array_values($datos))."', 2)";

        # Conectar a la base de datos, ejecutar y desconectar.
        // $db = Database::conectar();
        // $db->exec($query);
        // $db = Database::desconectar();
    }

    public function updateById($id)
    {
        /**
         * 1. Conectar a la base de datos.
         * 2. Construir la query para actualizar datos
         * 3. Ejecutar la query
         * 4. Desconectar de la base de datos
         */
        $query ="UPDATE pedidos SET";
        /**
         * Comprobamos valores getXX de id, dni, fecha, apellido_id
         * Si hay contenido, concateno.
         * Si no hay contenido, no hago nada
         */
       
        # $datos contiene un array con todos los datos existentes para actualizar
        $datos = array(); 
 
        if ($this->getfecha() != null) {
            $datos['fecha'] = $this->getfecha();
        }
        if ($this->getidcliente() != null) {
            $datos['id_cliente'] = $this->getidcliente();
        }
        if ($this->getdireccionentrega() != null) {
            $datos['direccion_entrega'] = $this->getdireccionentrega();
        }
        if ($this->gettotal() != null) {
            $datos['total'] = $this->gettotal();
        }
        
        # Recorrer los elementos de $datos
        $keys = array_keys($datos);
        // var_dump($datos);
        // var_dump($keys);
        
        foreach ($datos as $key => $value) {
            # estoy en el ultimo caso. NO PONGO COMA AL FINAL
            if($key === end($keys)){
                $query = $query . " $key = '$value'";
                var_dump('ULTIMO CASO: '. $query);
            }else{
                # Estoy en un caso normal. PONGO COMA AL FINAL
                $query = $query . " $key = '$value', ";
                var_dump('CASO NORMAL: '. $query);
            }
        }
        // var_dump('CASO FINAL: '. $query);
        // exit();
        $query = $query . " WHERE id =" . $id['id'];
        // var_dump('QUERY FINAL: '. $query);
        // exit();
        $database = new Database('root', '', 'localhost', 3306);
        $resultado = $database->exec($query);

        if($resultado == 1){
            $_SESSION['mensaje'] = 'Actualizado correctamente';
        }else{
            $_SESSION['mensaje'] = 'Error al actualizar. MIRAR MODELO';
        }
        $database = Database::desconectar();
    }

    public function destroyById($id) : void
    {
        /**
         * 1. Conectar a la base de datos
         * 2. Realizar la query correspondiente.
         * 3. Desconectar de la base de datos.
         */
        $database = new Database('root', '', 'localhost', 3306);
        $query = "DELETE FROM users WHERE id = $id";
        $database->exec($query);
        $database = Database::desconectar();
    }
}
?>