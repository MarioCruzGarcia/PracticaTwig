<?php

// Aqui cargamos las dependencias de TWIG que se han instalado
require_once 'vendor/autoload.php';


require_once 'controller/ClientesController.php';
require_once 'controller/Controller.php';
require_once 'controller/IndexController.php';
require_once 'controller/PedidosController.php';
require_once 'controller/pedidos_has_productosController.php';
require_once 'controller/pedidos_has_estadosController.php';

 require_once 'controller/ProductosController.php';



// Insertamos las dependencias del proyecto
// require_once 'autoload.php';
require_once 'Router.php';
require_once 'db/Database.php';

session_start();

// $db = Database::conectar();
// Database::iniciarTablas($db);

// Configuramos Twig.
/**
 * $loader contiene la ubicacion de mis vistas de twig
 * 
 * $twig contiene todo el entorno configurado del motor de plantillas.
 *  - Ubicacion de plantillas.
 *  - Variables globales
 *  - etc
 */
$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);
$twig->addGlobal('URL', $_SERVER['REQUEST_URI']);

/**
 * Configuracion del sistema de rutas
 */
$route = new Router();
$route->get('/',[IndexController::class,'index'])

      ->get('/index-clientes', [ClientesController::class, 'index'])
      ->get('/create-clientes', [ClientesController::class, 'create'])
      ->post('/store-clientes', [ClientesController::class, 'save'])
      ->get('/edit-clientes', [ClientesController::class, 'edit'])
      ->post('/update-clientes', [ClientesController::class, 'update'])
      ->get('/destroy-clientes', [ClientesController::class, 'destroy'])

      ->get('/index-pedidos', [PedidosController::class, 'index'])
      ->get('/create-pedidos', [PedidosController::class, 'create'])
      ->post('/store-pedidos', [PedidosController::class, 'save'])
      ->get('/edit-pedidos', [PedidosController::class, 'edit'])
      ->post('/update-pedidos', [PedidosController::class, 'update'])
      ->get('/destroy-pedidos', [PedidosController::class, 'destroy'])
      
      ->get('/index-productos', [ProductosController::class, 'index'])
      ->get('/create-productos', [ProductosController::class, 'create'])
      ->post('/store-productos', [ProductosController::class, 'save'])
      ->get('/edit-productos', [ProductosController::class, 'edit'])
      ->post('/update-productos', [ProductosController::class, 'update'])
      ->get('/destroy-productos', [ProductosController::class, 'destroy'])

      ->get('/index-pedidos_has_productos', [Pedidos_has_productosController::class, 'index'])
      ->get('/create-pedidos_has_productos', [Pedidos_has_productosController::class, 'create'])
      ->post('/store-pedidos_has_productos', [Pedidos_has_productosController::class, 'save'])
      ->get('/edit-pedidos_has_productos', [Pedidos_has_productosController::class, 'edit'])
      ->post('/update-pedidos_has_productos', [Pedidos_has_productosController::class, 'update'])
      ->get('/destroy-pedidos_has_productos', [Pedidos_has_productosController::class, 'destroy'])
      
      ->get('/index-pedidos_has_estados', [Pedidos_has_estadosController::class, 'index'])
      ->get('/create-pedidos_has_estados', [Pedidos_has_estadosController::class, 'create'])
      ->post('/store-pedidos_has_estados', [Pedidos_has_estadosController::class, 'save'])
      ->get('/edit-pedidos_has_estados', [Pedidos_has_estadosController::class, 'edit'])
      ->post('/update-pedidos_has_estados', [Pedidos_has_estadosController::class, 'update'])
      ->get('/destroy-pedidos_has_estados', [Pedidos_has_estadosController::class, 'destroy'])
      ;

$route->resolver_ruta($_SERVER['REQUEST_URI'], $_SERVER['REQUEST_METHOD']);

