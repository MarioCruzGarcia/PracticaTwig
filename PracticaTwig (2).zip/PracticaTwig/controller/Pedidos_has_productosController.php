<?php
    require_once 'controller/Controller.php';
    require_once 'model/Pedidos_has_productos.php';
 class Pedidos_has_productosController implements Controller{
    
    # Funcion abstracta index que muestra todos los elementos (tabla)
    public static function index(){
        $user = new Pedidos_has_productos();
        $users = $user->findAll();
        echo $GLOBALS['twig']->render('pedidos_has_productos/index.twig',
        [
            'pedidosproductos' => $users
        ]);
        // include 'views/private/user/index.php';
    }

    # Funcion abstracta create que muestra un formulario para agregar un elemento
    public static function create(){
        echo $GLOBALS['twig']->render('pedidos_has_productos/create.twig');
        // include 'views/private/user/create.php';
    }

    # Funcion abstracta save que inserta en la BD los elementos recogidos del formulario
    public static function save(){
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT, ['cont' => 4]);
        
        $user = new Pedidos_has_productos();
        $datos = array(
            'email' => $email,
            'password' => $password,
            'rol_id' => 1
        );

        $user->store($datos);

        header('Location: index-pedidos_has_productos');

    }

    # Funcion abstracta edit que recibe un $id de un elemento y muestra un formulario con su datos
    public static function edit($id){
        # Caso de administrador
        # Compruebo si existe la variable id dentro de los parametros que recibo (que pueden ser varios)
        if(isset($id['id'])){
            $cliente = new Pedidos_has_productos();
            $pedidos_has_productos = $cliente->findById($id['id'])->fetch();
            // include 'views/private/user/edit.php';
            echo $GLOBALS['twig']->render('pedidos_has_productos/edit.twig',[
                'cliente' => $pedidos_has_productos
            ]);
        }
        
    }

    # Funcion abstracta update que recibe un $id de un elemento y actualiza su contenido
    public static function update($id){
        $dni = $_POST['dni'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $correo = $_POST['correo'];
        $direccion = $_POST['direccion'];


    
        $user = new pedidos_has_productos();
        $user->setDNI($dni);
        $user->setNombre($nombre);
        $user->setApellido($apellido);
        $user->setCorreo($correo);
        $user->setDireccion($direccion);



        
        $user->updateById($id['id']);

        header('Location: index-pedidos_has_productos');
    }

    # Function abstracta destroy que recibe un $id de un elemento y lo elimina de la BD
    public static function destroy($id){
        $user = new pedidos_has_productos();
        $user->destroyById($id['id']);
        header('Location: index-pedidos_has_productos');
    }

 }

?>