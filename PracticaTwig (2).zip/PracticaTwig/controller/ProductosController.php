<?php
    require_once 'controller/Controller.php';
    require_once 'model/Productos.php';
 class ProductosController implements Controller{
    
    # Funcion abstracta index que muestra todos los elementos (tabla)
    public static function index(){
        $producto = new Productos();
        $users = $producto->findAll();
    
        $orden = isset($_GET['orden']) ? $_GET['orden'] : 'asc';
        if($orden == 'desc'){
            $users = $users->fetchAll(PDO::FETCH_ASSOC);
            usort($users, function($a, $b) {
                return $a['precio'] < $b['precio'] ? -1 : 1;
            });
        } else {
            $users = $users->fetchAll(PDO::FETCH_ASSOC);
            usort($users, function($a, $b) {
                return $a['precio'] > $b['precio'] ? -1 : 1;
            });
        }
    
        echo $GLOBALS['twig']->render('Productos/index.twig', [
            'productos' => $users
        ]);
    }

    # Funcion abstracta create que muestra un formulario para agregar un elemento
    public static function create(){
        echo $GLOBALS['twig']->render('Productos/create.twig');
    }

    # Funcion abstracta save que inserta en la BD los elementos recogidos del formulario
    public static function save(){
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $precio = $_POST['precio'];
        $stock = $_POST['stock'];
        
        
        $producto = new productos();
        $datos = array(
            'nombre' => $nombre,
            'descripciom' => $descripcion,
            'precio' => $precio,
            'stock' => $stock
        );

        $producto->store($datos);

        header('Location: index-productos');

    }

    # Funcion abstracta edit que recibe un $id de un elemento y muestra un formulario con su datos
    public static function edit($id){
        # Caso de administrador
        # Compruebo si existe la variable id dentro de los parametros que recibo (que pueden ser varios)
        if(isset($id['id'])){
            $producto = new Productos();
            $productos = $producto->findById($id['id'])->fetch();
            // include 'views/private/user/edit.php';
            echo $GLOBALS['twig']->render('Productos/edit.twig',[
                'producto' => $productos
            ]);
        }
        
    }

    # Funcion abstracta update que recibe un $id de un elemento y actualiza su contenido
    public static function update($id){
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $precio = $_POST['precio'];
        $stock = $_POST['stock'];

        $producto = new Productos();
        $producto->setNombre($nombre);
        $producto->setdescripcion($descripcion);
        $producto->setPrecio($precio);
        $producto->setStock($stock);
        
        $producto->updateById($id);
        header('Location: index-productos');

       
    }

    # Function abstracta destroy que recibe un $id de un elemento y lo elimina de la BD
    public static function destroy($id){
        $user = new Productos();
        $user->destroyById($id['id']);
        header('Location: index-productos');
    }

 }

?>