<?php
require_once 'controller/Controller.php';
require_once 'model/Pedidos_Has_Estado.php';

class Pedidos_has_estadosController implements Controller
{
    # Funcion abstracta index que muestra todos los elementos (tabla)
    public static function index()
    {
        $pedidoHasEstado = new PedidoHasEstado();
        $pedidosHasEstados = $pedidoHasEstado->findAll();
        echo $GLOBALS['twig']->render('Pedidos_Has_Estado/index.twig', [
            'estados' => $pedidosHasEstados
        ]);
    }

    # Funcion abstracta create que muestra un formulario para agregar un elemento
    public static function create()
    {
        // Obtener los valores de id_pedido y id_estado desde alguna fuente (por ejemplo, un select)
        // Luego, asignarlos a las variables $idPedido y $idEstado

        echo $GLOBALS['twig']->render('Pedidos_Has_Estado/create.twig');
    }

    # Funcion abstracta save que inserta en la BD los elementos recogidos del formulario
    public static function save()
    {
        $idPedido = $_POST['id_pedido'];
        $idEstado = $_POST['id_estado'];
        $fecha = date('Y-m-d H:i:s'); // Fecha actual

        $pedidoHasEstado = new PedidoHasEstado();
        $pedidoHasEstado->setIdPedido($idPedido);
        $pedidoHasEstado->setIdEstado($idEstado);
        $pedidoHasEstado->setFecha($fecha);

        $pedidoHasEstado->store($pedidoHasEstado->getValues());

        header('Location: index-pedido_has_estado');
    }

    # Funcion abstracta edit que recibe un $id de un elemento y muestra un formulario con su datos
    public static function edit($id)
    {
        if (isset($id['id'])) {
            $pedidoHasEstado = new PedidoHasEstado();
            $pedidoHasEstado = $pedidoHasEstado->findById($id['id'])->fetch();
    
            echo $GLOBALS['twig']->render('Pedidos_Has_Estado/edit.twig', [
                'estado' => $pedidoHasEstado // Pasar el estado del pedido a la vista
            ]);
        }
    }
    

    # Funcion abstracta update que recibe un $id de un elemento y actualiza su contenido
    public static function update($id)
    {
        $idPedido = $_POST['id_pedido'];
        $idEstado = $_POST['id_estado'];
        $fecha = $_POST['fecha'] ;

        $pedidoHasEstado = new PedidoHasEstado();
        $pedidoHasEstado->setId($id['id']);
        $pedidoHasEstado->setIdPedido($idPedido);
        $pedidoHasEstado->setIdEstado($idEstado);
        $pedidoHasEstado->setFecha($fecha);

        $pedidoHasEstado->updateById($pedidoHasEstado->getValues());

        header('Location: index-pedido_has_estado');
    }

    # Function abstracta destroy que recibe un $id de un elemento y lo elimina de la BD
    public static function destroy($id)
    {
        $pedidoHasEstado = new PedidoHasEstado();
        $pedidoHasEstado->destroyById($id['id']);

        header('Location: index-pedido_has_estado');
    }
}
?>