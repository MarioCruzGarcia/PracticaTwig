<?php
    require_once 'controller/Controller.php';
    require_once 'model/Pedidos.php';
 class PedidosController implements Controller{
    
    # Funcion abstracta index que muestra todos los elementos (tabla)
    public static function index(){
        $user = new Pedidos();
        $users = $user->findAll();
        echo $GLOBALS['twig']->render('Pedidos/index.twig',
        [
            'pedidos' => $users
        ]);
        // include 'views/private/user/index.php';
    }

    # Funcion abstracta create que muestra un formulario para agregar un elemento
    public static function create(){
        echo $GLOBALS['twig']->render('user/create.twig');
        // include 'views/private/user/create.php';
    }

    # Funcion abstracta save que inserta en la BD los elementos recogidos del formulario
    public static function save(){
        $fecha = $_POST['fecha'];
        $idcliente = $_POST['idcliente'];
        $direccionentrega = $_POST['direccionentrega'];
        $total = $_POST['total'];

        
        
        $pedido = new pedidos();
        $datos = array(
            'fecha' => $fecha,
            'idcliente' => $idcliente,
            'direccionentrega' => $direccionentrega,
            'total' => $total

            
        );

        $pedido->store($datos);

        header('Location: index-pedidos');

    }

    # Funcion abstracta edit que recibe un $id de un elemento y muestra un formulario con su datos
    public static function edit($id){
        # Caso de administrador
        # Compruebo si existe la variable id dentro de los parametros que recibo (que pueden ser varios)
        if(isset($id['id'])){
            $pedido = new Pedidos();
            $pedidos = $pedido->findById($id['id'])->fetch();
            // include 'views/private/user/edit.php';
            echo $GLOBALS['twig']->render('pedidos/edit.twig',[
                'pedido' => $pedidos
            ]);
        }
        
    }

    # Funcion abstracta update que recibe un $id de un elemento y actualiza su contenido
    public static function update($id){
        $fecha = $_POST['fecha'];
        $idcliente = $_POST['id_cliente'];
        $direccionentrega = $_POST['direccion_entrega'];
        $total = $_POST['total'];

        $pedido = new pedidos();
        $pedido->setfecha($fecha);
        $pedido->setidcliente($idcliente);
        $pedido->setdireccionentrega($direccionentrega);
        $pedido->settotal($total);
        
        $pedido->updateById($id);
        header('Location: index-pedidos');

       
    }
    # Function abstracta destroy que recibe un $id de un elemento y lo elimina de la BD
    public static function destroy($id){
        $user = new Pedidos();
        $user->destroyById($id['id']);
        header('Location: index-user');
    }

 }

?>