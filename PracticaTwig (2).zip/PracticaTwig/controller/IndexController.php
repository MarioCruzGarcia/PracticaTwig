<?php
class IndexController{

    public static function index(){
        // Forma antigua de intoducir una vista
        // include 'views/index.php';

        // Ahora usaremos TWIG para insertar una vista.
        /**
         * Realizar render de index.twig
         */
        // var_dump(URL);
        // exit();
        echo $GLOBALS['twig']->render('index.twig');

    }
}

?>